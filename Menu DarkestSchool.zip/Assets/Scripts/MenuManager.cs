using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MenuManager : MonoBehaviour
{
    [Header("--------------- Games ---------------")]
    [SerializeField] private string GameNamePortuguese;
    [SerializeField] private string GameNameEnglish;
    [SerializeField] private string GameNameSpanish;

    [Header("--------------- Menus ---------------")]
    [SerializeField] private string MenuPortuguese;
    [SerializeField] private string MenuEnglish;
    [SerializeField] private string MenuSpanish;

    [Header("--------------- Telas ---------------")]
    [SerializeField] private GameObject MenuPrincipal;
    [SerializeField] private GameObject Opcoes;
    [SerializeField] private GameObject opcaoSons;
    [SerializeField] private GameObject opcaoIdioma;
    [SerializeField] private GameObject opcaoAcessibilidade;
    [SerializeField] private GameObject Creditos;


    public void JogarPort(){
        SceneManager.LoadScene(GameNamePortuguese);
    }

    public void JogarEng(){
        SceneManager.LoadScene(GameNameEnglish);
    }

    public void JogarSpan(){
        SceneManager.LoadScene(GameNameSpanish);
    }


    public void MenuPort(){
        SceneManager.LoadScene(MenuPortuguese);
    }

    public void MenuEng(){
        SceneManager.LoadScene(MenuEnglish);
    }

    public void MenuSpan(){
        SceneManager.LoadScene(MenuSpanish);
    }


    public void abrirOpcoes(){
        MenuPrincipal.SetActive(false);
        Opcoes.SetActive(true);
    }

    public void fecharOpcoes(){
        MenuPrincipal.SetActive(true);
        Opcoes.SetActive(false);
    }

    public void abrirSons(){
        opcaoIdioma.SetActive(false);
        opcaoAcessibilidade.SetActive(false);
        opcaoSons.SetActive(true);
    }

    public void abrirIdioma(){
        opcaoSons.SetActive(false);
        opcaoAcessibilidade.SetActive(false);
        opcaoIdioma.SetActive(true);
    }

    public void abrirAcessibilidade(){
        opcaoSons.SetActive(false);
        opcaoIdioma.SetActive(false);
        opcaoAcessibilidade.SetActive(true);
    }

    public void abrirCreditos(){
        MenuPrincipal.SetActive(false);
        Creditos.SetActive(true);
    }

    public void fecharcreditos(){
        MenuPrincipal.SetActive(true);
        Creditos.SetActive(false);
    }

    public void SairDoJogo(){
        Debug.Log("Saiu do Jogo");
        Application.Quit();
    }
}
