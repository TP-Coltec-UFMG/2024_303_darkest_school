using UnityEngine;
using UnityEngine.UI;

public class FiltroDaltonico : MonoBehaviour
{
    [Header("--------------- Filtros Daltônicos ---------------")]
    public Toggle toggleNone;
    public Toggle toggleProtanopia;
    public Toggle toggleDeuteranopia;
    public Toggle toggleTritanopia;
    void Start(){
        if(PlayerPrefs.GetInt("ToggleBool") == 1){
            toggleNone.isOn = true;
        }
        else{
            toggleNone.isOn = false;
        }

        if(PlayerPrefs.GetInt("ToggleBool1") == 1){
            toggleProtanopia.isOn = true;
        }
        else{
            toggleProtanopia.isOn = false;
        }

        if(PlayerPrefs.GetInt("ToggleBool2") == 1){
            toggleDeuteranopia.isOn = true;
        }
        else{
            toggleDeuteranopia.isOn = false;
        }

        if(PlayerPrefs.GetInt("ToggleBool3") == 1){
            toggleTritanopia.isOn = true;
        }
        else{
            toggleTritanopia.isOn = false;
        }
    }

    void Update(){
        if(toggleNone.isOn == true){
            PlayerPrefs.SetInt("ToggleBool", 1);
        }
        else{
            PlayerPrefs.SetInt("ToggleBool", 0);
        }

        if(toggleProtanopia.isOn == true){
            PlayerPrefs.SetInt("ToggleBool1", 1);
        }
        else{
            PlayerPrefs.SetInt("ToggleBool1", 0);
        }

        if(toggleDeuteranopia.isOn == true){
            PlayerPrefs.SetInt("ToggleBool2", 1);
        }
        else{
            PlayerPrefs.SetInt("ToggleBool2", 0);
        }

        if(toggleTritanopia.isOn == true){
            PlayerPrefs.SetInt("ToggleBool3", 1);
        }
        else{
            PlayerPrefs.SetInt("ToggleBool3", 0);
        }
    }
}
